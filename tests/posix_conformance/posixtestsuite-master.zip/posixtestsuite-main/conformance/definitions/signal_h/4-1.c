  /*
  Test the definition of sigset_t.
  */

#include <signal.h>

sigset_t dummy;
