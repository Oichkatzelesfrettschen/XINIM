  /*
  Test that the BUS_ADRERR macro is defined.
  */

#include <signal.h>

#ifndef BUS_ADRERR
#error BUS_ADRERR not defined
#endif
