  /*
  Test that the BUS_ADRALN macro is defined.
  */

#include <signal.h>

#ifndef BUS_ADRALN
#error BUS_ADRALN not defined
#endif
